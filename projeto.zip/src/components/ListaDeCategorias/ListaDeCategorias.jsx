import React, { Component } from 'react';
import './estilo.css';

class ListaDeCategorias extends Component{

    _handleEventoInput(evento){
        if(evento.key == "Enter"){
            let valorCategoria = evento.target.value;
            this.props.adicionarCategoria(valorCategoria);
        }
    }

    render(){
        return(
            <section>

                <ul className="estilo">
                    {this.props.categorias.map((categoria, index)=>{
                        return (
                            <li key="index">{ categoria }</li>
                        )
                    })}                   
                </ul>

                
                <input type="text" className="inputCategoria" placeholder="Adicionar categoria"
                onKeyUp={this._handleEventoInput.bind(this)}
                />
                

            </section>
        )
    }
}

export default ListaDeCategorias;